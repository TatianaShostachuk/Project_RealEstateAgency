function show(backcall_id){

    display = document.getElementById(backcall_id).style.display;

 

    if(display=='none'){

       document.getElementById(backcall_id).style.display='block';

    }else{

       document.getElementById(backcall_id).style.display='none';

    }

}


function hide(backcall_id){

    display = document.getElementById(backcall_id).style.display;

 

    if(display=='block'){

       document.getElementById(backcall_id).style.display='none';

    }else{

       document.getElementById(backcall_id).style.display='block';

    }

}
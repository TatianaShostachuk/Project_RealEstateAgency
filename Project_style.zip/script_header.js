var firstlink = getElementBy

var firstlink= document.getElementById('firstlink');
    var firstlist = firstlink.querySelector('firstlist');

    titleElem.moseover = function() {
      firstlist.classList.toggle('open');
    };